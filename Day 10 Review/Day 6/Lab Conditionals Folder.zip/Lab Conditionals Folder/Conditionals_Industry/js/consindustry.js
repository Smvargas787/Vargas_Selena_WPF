
/*
 Selena Vargas
 Conditionals Industry
 WPF 1411
 11/7/14
 */

//alert("Testing 1, 2, 3!");

//Website Pricing

alert("It's time to make Selena money!");
alert("A local Web Designing company is wanting to make new hires for their Web Development field and showed you a list of their annual salaries " +
"they are willing to pay you.");

var annualSalary = prompt("What is your requested salary you are wanting to receieve from your company?");

if(annualSalary==""){
 console.log("Please enter some valid information.");
 annualSalary = prompt("What is your requested salary you are wanting to receieve from your company?");



}else{
 console.log("Thank you, please proceed.");

}


if(annualSalary>=6000000000){
 console.log("You're asking for a little too much there buddy, but you're getting paid!!")


}else if(annualSalary>=5650000000){
 console.log("You're not a Donald Trump but you're making it up there!");


}else if(annualSalary>=32000000){
 console.log("You're wanting to be rich! I see it!");


}else if(annualSalary>=23000){
 console.log("You're wanting to be an average civilian huh? That's always nice.")


}else if(annualSalary>=1500){
 console.log("I hope you have another job because those bills aren't going to get paid that easily with this income.")

}else if(annualSalary<=100){
 console.log("You fail at life if you're only wanting this much.")

} 