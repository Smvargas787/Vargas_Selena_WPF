/*
Selena Vargas
Wacky Expressions
WPF 1411
11-3-14
 */

alert("Ha Ha! You have fallen into my comedy trap!");

var jokeIntro = prompt("The following are going to be a series of knock knock jokes that you must laugh obnoxiously to\n" +
"or walk away with the thought in your mind that you just crushed my comedian career. Click ok to continue.");
console.log("The following are going to be a series of knock knock jokes that you must laugh obnoxiously to\n" +
"or walk away with the thought in your mind that you just crushed my comedian career. Click ok to continue. "+jokeIntro+"");

//Joke 1
var joke1 = prompt("Round 1!\nKnock knock!\n(1): Who's There?");
console.log("Round"+joke1+" 1!\nKnock knock!\n1:Who's There?");

var actualJoke = prompt("Boo!\n(2): Boo who?");
console.log("Boo!\n("+actualJoke+"):Boo who?");


var jokeAnswer = prompt("Awwh, don't cry. I'm just telling you jokes in alert forms.\n(1):Kevin Hart Material");
console.log("Awwh, don't cry. I'm just telling you jokes in alert forms.\n("+jokeAnswer+"):Kevin Hart Materal.");

alert("I know, I know, I'm the next Kevin Hart.");
var hilarous = "Kevin Hart";
console.log("I know, I know, I'm the next "+hilarous+".");


//Joke 2
var joke2 = prompt("Round 2!\nKnock knock!\n(2): Who's There?");
console.log("Round 2!\nKnock knock!\n"+joke2+":Who's There?");

var actualJoke2 = prompt("Aren't I?\n(1): Aren't I who?");
console.log("Aren't I?\n("+actualJoke2+"):Aren't I who?");


var jokeAnswer2 = prompt("Aren't I just amazing at telling jokes?!.\n(2):No");
console.log("You could of just played along.\n("+jokeAnswer2+"):No.");

alert("Well that hurt a little bit.");

var hilarous2 = "hurt";
console.log("Well that "+hilarous2+" a little bit.");

//Joke 3


var joke3 = prompt("Round 3!\nKnock knock!\n(3): Who's There?");
console.log("Round 3!\nKnock knock!\n("+joke3+"):Who's There?");


var actualJoke3 = prompt("Orange\n(3): Orange who?");
console.log("Orange!\n("+actualJoke3+"):Orange who?");


var jokeAnswer3 = prompt("Orange you glad that I didn't tell another joke?\n(3):YES!!!!");
console.log("Orange you glad I didn't tell another joke?\n("+jokeAnswer3+"):YES!!!");


alert("It's a good thing you don't grade according to a laugh meter then right?");
var hilarous3 = "YES!!!";
console.log("It's a good thing you don't grade according to a laugh meter then right? "+hilarous3+".");
